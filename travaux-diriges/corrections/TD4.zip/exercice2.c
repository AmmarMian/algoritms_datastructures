#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int len_str(const char* str) {
    int len = 0;
    while (str[len] != '\0') len++;
    return len;
}

char* concatenate(const char* str1, const char* str2) {
    // Calculate lengths of str1 and str2
    int len1 = len_str(str1);
    int len2 = len_str(str2);

    // Allocate memory for the new string
    char* result = (char*)malloc(len1 + len2 + 1);
    if (result == NULL) {
        printf("Memory allocation failed.\n");
        exit(1);
    }

    // Copy str1 into result
    for (int i = 0; i < len1; i++) {
        result[i] = str1[i];
    }

    // Copy str2 into result
    for (int i = 0; i < len2; i++) {
        result[len1 + i] = str2[i];
    }

    // Null-terminate the result
    result[len1 + len2] = '\0';

    return result;
}

char* concatenate_realloc(const char* str1, const char* str2) {
    // Calculate lengths of str1 and str2
    int len1 = len_str(str1);
    int len2 = len_str(str2);

    // Reallocate memory for the new string into str1
    char* result = (char*)realloc((char*)str1, len1 + len2 + 1);
    // Copy str2 into str1
    for (int i = 0; i < len2; i++) {
      result[len1 + i] = str2[i];
    }
    // Null-terminate the result
    result[len1 + len2] = '\0';

    return result;
}


int main(int argc, char *argv[])
{
  // Allocate dynamic memory for str1
  // THIS IS VERY IMPORTANT BECAUSEIF WE USED A STRING LITTERAL, WE WOULD NOT BE ABLE TO MODIFY IT -> Adress boundary error
  char* str1 = (char*)malloc(8 * sizeof(char)); // 8 to fit "Hello, "
  if (str1 == NULL) {
      printf("Memory allocation failed.\n");
      exit(1);
  }
  strcpy(str1, "Hello, ");
  char* str2 = "world!";
  char* result = concatenate(str1, str2);
  printf("Adress of str1: %p\n", str1);
  printf("Adress of str2: %p\n", str2);
  printf("Malloc: adress %p, value %s\n", result, result);

  result = concatenate_realloc(str1, str2);
  printf("Realloc: adress %p, value %s\n", result, result);
  free(result);

  // Last question
  char* sentence = (char*)malloc(sizeof(char));
  char word[50];  // Buffer to hold each word
  int current_length = 0;

  if (sentence == NULL) {
      printf("Memory allocation failed.\n");
      return 1;
  }

  sentence[0] = '\0';  // Start with an empty string

  printf("Enter words to build a sentence (type 'STOP' to end):\n");

  while (1) {
    scanf("%49s", word);  // Read a word (max 49 characters)
    
    if (strcmp(word, "STOP") == 0) {
        break;
    }

    sentence = concatenate_realloc(sentence, " ");  // Add a space between words
    // Check if the memory allocation was successful
    if (sentence == NULL) {
      printf("Memory allocation failed.\n");
      return 1;
    }

    sentence = concatenate_realloc(sentence, word);  // Add the word
    // Check if the memory allocation was successful
    if (sentence == NULL) {
      printf("Memory allocation failed.\n");
      return 1;
    }
  }

  printf("Complete Sentence: %s\n", sentence);

  // Free the allocated memory
  free(sentence);

  return EXIT_SUCCESS;
}
