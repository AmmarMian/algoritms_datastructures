#include <stdio.h>
#include <stdlib.h>

void print_matrix(double **matrix, int m, int n){
  for(int i = 0; i < m; i++){
    for(int j = 0; j < n; j++){
      printf("%f ", matrix[i][j]);
    }
    printf("\n");
  }
}


double** allocate_matrix(int n, int m){
  double **matrix = calloc(n, sizeof(double*));
  for (int i=0; i<n; i++) {
    matrix[i] = calloc(m, sizeof(double));
  }
  return matrix;
}

void free_matrix(double **matrix, int n){
  for (int i=0; i<n; i++) {
    free(matrix[i]);
  }
  free(matrix);
}


int main(int argc, char *argv[])
{
  double **matrix = allocate_matrix(3, 3);
  for (int i=0; i<3; i++) {
    for (int j=0; j<3; j++) {
      if (i==j) {
        matrix[i][j] = 1;
      }
      else {
        matrix[i][j] = 0;
      }
    }
  }
  printf("Matrice identité\n");
  print_matrix(matrix, 3, 3);

  free_matrix(matrix, 3);

  return EXIT_SUCCESS;
}
