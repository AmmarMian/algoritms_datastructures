#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node* next;
    struct node* prev;
};

typedef struct node Node;

typedef struct {
  Node* head;
  Node* tail;
} List;


List create_list() {
  List list;
  list.head = NULL;
  list.tail = NULL;
  return list;
}


int length_list(List* list) {
  int length = 0;
  Node* current = list->head;
  while (current != NULL) {
    length++;
    current = current->next;
  }
  return length;
}

void insert_node(List* list, int data) {
  Node* new_node = (Node*)malloc(sizeof(Node));
  new_node->data = data;
  new_node->next = NULL;
  if (list->head == NULL) {
    new_node->prev = NULL;
    list->head = new_node;
    list->tail = new_node;
  } else {
    new_node->prev = list->tail;
    list->tail->next = new_node;
    list->tail = new_node;
  }
}

void print_list(List* list) {
  Node* current = list->head;
  while (current != NULL) {
    printf("%d ", current->data);
    current = current->next;
  }
  printf("\n");
}


void reverse_list(List* list) {
  if (list->head == NULL) {
    return;
  }
  Node* current = list->head;
  Node* temp = NULL;
  while (current != NULL) {
    printf("current: %d\n", current->data);
    temp = current->next;
    current->next = current->prev;
    current->prev = temp;
    current = temp;
  }
  temp = list->head;
  list->head = list->tail;
  list->tail = temp;
}

int main(int argc, char *argv[])
{
  List list = create_list();
  insert_node(&list, 1);
  insert_node(&list, 2);
  insert_node(&list, 3);
  insert_node(&list, 4);

  printf("Original list: ");
  print_list(&list);
  printf("List length: %d\n", length_list(&list));

  printf("Reversed list: ");
  reverse_list(&list);
  print_list(&list);


  return EXIT_SUCCESS;
}


