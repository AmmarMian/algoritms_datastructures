
typedef struct {
  int x;
  int y;
} Point;


int count_occurence_int(int tab[], int size, int value){
  int count = 0;
  for(int i = 0; i < size; i++){
      if(tab[i] == value){
          count++;
      }
  }
  return count;
}
 

int count_occurence_point(Point *tab, int size, Point value){
  int count = 0;
  for(int i = 0; i < size; i++){
    // Insister sur tab->x = (*tab).x 
      if((tab+i)->x == value.x && (tab+i)->y == value.y){
          count++;
      }
  }
  return count;
}
