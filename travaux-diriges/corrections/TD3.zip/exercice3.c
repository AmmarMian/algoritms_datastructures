#include <stdio.h>
void f(int a, int *b) {
  a = 5;
  *b = 10;
}

void f_correct(int *a, int *b) {
  *a = 5;
  *b = 10;
}

void swap(int *a, int *b) {
  int tmp = *a;
  *a = *b;
  *b = tmp;
}


int main() {
  int x = 1;
  int y = 2;
  f(x, &y);
  printf("%d %d\n", x, y);
  f_correct(&x, &y);
  printf("%d %d\n", x, y);

  int tab[7] = {1, 2, 3, 4, 5, 6, 7};
  swap(&tab[2], &tab[4]);
  return 0;
}
