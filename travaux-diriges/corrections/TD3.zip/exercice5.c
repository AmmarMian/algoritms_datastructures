#include <stdio.h>
#include <stdlib.h>

void print_matrix(double *matrix, int m, int n){
  for(int i = 0; i < m; i++){
    for(int j = 0; j < n; j++){
      printf("%f ", matrix[i*n + j]);
    }
    printf("\n");
  }
}

void transpose(double *matrix, int m){
  for(int i = 0; i < m; i++){
    for(int j = i+1; j < m; j++){
      double tmp = matrix[i*m + j];
      matrix[i*m + j] = matrix[j*m + i];
      matrix[j*m + i] = tmp;
    }
  }
}

void dot_product(double *matrix1, double *matrix2, double *result, int m, int n, int p){
  for(int i = 0; i < m; i++){
    for(int j = 0; j < p; j++){
      double sum = 0;
      for(int k = 0; k < n; k++){
        sum += matrix1[i*n + k] * matrix2[k*p + j];
      }
      result[i*p + j] = sum;
    }
  }
}



int main(int argc, char *argv[])
{
  double identity[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  double matrix1[16] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14,15, 16};
  
  printf("Identity:\n");
  print_matrix(identity, 3, 3);
  printf("\n");

  printf("Matrix1:\n");
  print_matrix(matrix1, 4, 4);
  printf("\nTranspose Matrix1:\n");
  transpose(matrix1, 4);
  print_matrix(matrix1, 4, 4);

  int m=5,n=3,p=4;
  double matrix2[15] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15};
  double matrix3[12] = {12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
  double result[20];
  dot_product(matrix2, matrix3, result, m, n, p);
  printf("\nMatrix2:\n");
  print_matrix(matrix2, m, n);
  printf("\nMatrix3:\n");
  print_matrix(matrix3, n, p);
  printf("\nResult:\n");
  print_matrix(result, m, p);


  return EXIT_SUCCESS;
}
