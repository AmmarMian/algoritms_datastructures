#include <stdio.h>
#include <stdbool.h>


void print_line(int n_stars, int n){
  int n_symbols = 2*(n-1)+1;
  int n_spaces = (n_symbols-n_stars)/2;
  for (int i=0; i<n_spaces; i++) {
   printf(" ");
  }
  for (int i=0; i<n_stars; i++) {
   printf("*");
  }
  printf("\n");
}


void print_triangle(int n){
  for (int i=0; i<n; i++){
    print_line(2*i+1, n);
  }
}

bool validate_height(int n){
  return n%2 == 1;
}

int scan_height(){
  int n;
  printf("Entrez une hauteur de triangle impaire: ");
  scanf("%d", &n);
  while (!validate_height(n)) {
    printf("\nErreur, veuillez entrer un nombre impair!\n");
    printf("Entrez une hauteur de triangle impaire: ");
    scanf("%d", &n);
  }
  return n;
}


int main() {
    printf("Programme d'affichage de triangle\n");
    int n = scan_height();
    print_triangle(n);

    return 0;
}
