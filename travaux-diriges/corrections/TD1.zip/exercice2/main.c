#include <stdio.h>
#include <stdlib.h>

// Version naive
int sum_for(int n){
  int resultat = 0;
  for (int i=1; i<n+1; i++) {
    resultat += i;
  }
  return resultat;
}

// Version intelligente
int sum_formula(int n){
  return n*(n+1)/2;
}

int factorielle(int n){
  int resultat = 1; 
  for (int i=1; i<n+1; i++) {
    resultat *= i;
  }
  return resultat;
}

 int main()
{
  int n;
  printf("Veuillez entrer un nombre : ");
  scanf("%d", &n);
  printf("\nLa somme avec boucle for est : %d\n", sum_for(n));
  printf("La somme avec boucle la formule est : %d\n", sum_formula(n));
  printf("\nLa factorielle est : %d\n", factorielle(n));
  return EXIT_SUCCESS;
}
