#include <stdio.h>

int pgcd(int a, int b) {
  int r;
  while (b != 0) {
    r = a % b;
    a = b;
    b = r;
  }
  return a;
}

int ppcm(int a, int b) {
  return a * b / pgcd(a, b);
}

int main() {
  int a, b;
  printf("Entrez deux entiers séparés par une virgule: ");
  scanf("%d, %d", &a, &b);
  printf("Le PGCD de %d et %d est %d\n", a, b, pgcd(a, b));
  printf("Le PPCM de %d et %d est %d\n", a, b, ppcm(a, b));
  return 0;
}
