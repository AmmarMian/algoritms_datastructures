#include <stdio.h>
#include <stdlib.h>

int pgcd(int a, int b) {
    int r = a % b;
    while(r != 0) {
        a = b;
        b = r;
        r = a % b;
    }
    return(b);
}

int ppcm(int a, int b){
  return a*b/pgcd(a, b);
}


int main(void)
{
  int a, b;
  printf("Entrez deux nombres entiers séparés par une virgule : ");
  scanf("%d, %d", &a, &b);
  printf("\nLe PGCD est %d et le PPCM est %d\n", pgcd(a, b), ppcm(a, b));
  return EXIT_SUCCESS;
}
