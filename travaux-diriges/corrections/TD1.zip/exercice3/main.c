#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double power(float x, int n){
  double resultat = 1;
  if (n==0){
    return 1;
  } else {
    return power(x, n-1)*x;
  }
}

int factorielle(int n){
  int resultat = 1; 
  for (int i=1; i<n+1; i++) {
    resultat *= i;
  }
  return resultat;
}

double sinus(float angle, int n){
  double resultat = 0;
  double cache_factorielle = 1;
  for (int i=0; i<=(n-1)/2; i++) {
    // resultat += power(-1, i)*power(angle, 2*i+1)/factorielle(2*i+1);
    resultat += power(-1, i)*power(angle, 2*i+1)/cache_factorielle;
    cache_factorielle *= (2*i+2)*(2*i+3);
  }
  return resultat;
}

int main(void)
{
  double angle;
  int n;
  printf("Veuillez entrer un angle et un ordre séparés par une virgule : ");
  scanf("%lf, %d", &angle, &n);
  printf("\nLe sinus de %f à l'ordre %d est : %f", angle, n, sinus(angle, n));

  int i = 1;
  double eps=0.0001;
  while (fabs(sinus(angle, i)-sin(angle))>eps) {
    printf("\nSinus ours : %lf, Sinus math : %lf", sinus(angle, i), sin(angle));
    i++;
  }
  printf("\nL'ordre est %d\n", i);


  return EXIT_SUCCESS;
}
