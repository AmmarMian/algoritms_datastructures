#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/traitement_chaines.h"
#include "../src/caesar.h"


int main(int argc, char *argv[])
{
  printf("Bienvue dans le programme de chiffrement de César\n");
  printf("Veuillez entrer le texte à chiffrer: \n");
  char *texte = get_line(stdin);
  // On elenve le retour à la ligne
  texte[strlen(texte) - 1] = '\0';
  printf("Veuillez entrer le décalage: \n");
  int decalage;
  scanf("%d", &decalage);
  encrypt_cesar(texte, decalage);
  printf("Texte chiffré: %s\n", texte);

  return EXIT_SUCCESS;
}

