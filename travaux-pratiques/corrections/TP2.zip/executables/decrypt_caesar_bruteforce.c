#include <stdio.h>
#include <stdlib.h>
#include "../src/decrypt_caesar.h"



int main(int argc, char *argv[])
{
  // Get filename and shift from command line
  if (argc != 3)
  {
    fprintf(stderr, "Usage: %s <filename> <dictionary>\n", argv[0]);
    return EXIT_FAILURE;
  }
  char *filename = argv[1];
  char *dictionary = argv[2];

   print_decryption_bruteforce_file(filename, dictionary);

  return EXIT_SUCCESS;
}
