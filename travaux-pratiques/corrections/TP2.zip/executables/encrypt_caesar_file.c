#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/traitement_chaines.h"
#include "../src/caesar.h"


int main(int argc, char *argv[])
{
  // Get filename and shift from command line
  if (argc != 3)
  {
    fprintf(stderr, "Usage: %s <filename> <shift>\n", argv[0]);
    return EXIT_FAILURE;
  }
  char *filename = argv[1];
  int shift = atoi(argv[2]);

  // Open file
  FILE *file = fopen(filename, "r");
  if (file == NULL)
  {
    perror("fopen");
    return EXIT_FAILURE;
  }

  // Read file line by line
  char *line = NULL;
  size_t len = 0;
  ssize_t read;
  while ((read = getline(&line, &len, file)) != -1)
  {
    // Remove newline character
    line[strlen(line) - 1] = '\0';
    encrypt_cesar(line, shift);
    printf("%s\n", line);
  }

  // Close file
  fclose(file);

  // Free memory
  free(line);

  return EXIT_SUCCESS;
}

