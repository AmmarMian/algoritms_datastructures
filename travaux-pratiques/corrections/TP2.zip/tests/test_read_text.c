// Fichier de test de fonctions sur les chaines de caractères
#include <stdio.h>
#include <stdlib.h>
#include "../src/traitement_chaines.h"


int main(){
    printf("Test de la fonction read_text\n");
    char * text = read_text(100, "Entrez un texte: ");
    printf("Texte: %s\n", text);
    free(text);
    return 0;
}
