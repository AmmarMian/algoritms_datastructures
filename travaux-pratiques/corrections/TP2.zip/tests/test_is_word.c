#include <stdio.h>
#include <stdlib.h>
#include "../src/decrypt_caesar.h"

int main(int argc, char *argv[])
{
  char *word = "salut";
  char *dictionary = "francais.txt";
  int result = is_word(word, dictionary);
  printf("is_word(\"%s\", \"%s\") = %d\n", word, dictionary, result);

  char *word2 = "salutaaaa";
  int result2 = is_word(word2, dictionary);
  printf("is_word(\"%s\", \"%s\") = %d\n", word2, dictionary, result2);
  return EXIT_SUCCESS;
}
