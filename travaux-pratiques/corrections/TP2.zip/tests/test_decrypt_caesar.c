// Fichier de test de fonction decrypt_cesar
#include <stdio.h>
#include <stdlib.h>
#include "../src/caesar.h"


int main(int argc, char *argv[])
{

  char chaine[] = "Erqmrxu frpphqw fd yd";
  int decalage = 3;
  printf("Test de la fonction decrypt_cesar décalage de %d\n", decalage);
  printf("Chaine avant déchiffrement: %s\n", chaine);
  decrypt_cesar(chaine, decalage);
  printf("Chaine après déchiffrement: %s\n", chaine);

  return EXIT_SUCCESS;
}

