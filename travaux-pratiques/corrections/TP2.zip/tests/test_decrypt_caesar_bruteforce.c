// Fichier de test de fonction decrypt_cesar
#include <stdio.h>
#include <stdlib.h>
#include "../src/decrypt_caesar.h"


int main(int argc, char *argv[])
{

  char chaine[] = "Erqmrxu frpphqw fd yd";
  printf("Chaine avant déchiffrement: %s\n", chaine);
  decrypt_cesar_bruteforce(chaine, "francais.txt");
  printf("Chaine après déchiffrement: %s\n", chaine);

  char chaine2[] = "kujkujkuj sn bdrb lxwcnwc mn xdo";
  printf("Chaine avant déchiffrement: %s\n", chaine2);
  decrypt_cesar_bruteforce(chaine2, "francais.txt");
  printf("Chaine après déchiffrement: %s\n", chaine2);


  return EXIT_SUCCESS;
}

