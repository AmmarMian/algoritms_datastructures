// Fichier de test de fonctions sur les chaines de caractères
#include <stdio.h>
#include <stdlib.h>
#include "../src/traitement_chaines.h"


int main(){
    printf("Test de la fonction get_line\n");
    printf("Entrez une ligne: ");
    char * line = get_line(stdin);
    printf("Ligne: %s\n", line);
    free(line);
    return 0;
}

