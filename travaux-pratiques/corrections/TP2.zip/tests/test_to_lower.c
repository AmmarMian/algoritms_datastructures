// Fichier de test de fonctions sur les chaines de caractères
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/traitement_chaines.h"


int main(int argc, char *argv[])
{
  // On est obligé de faire un malloc pour les charactères
  // car on ne peut pas assigner directement une valeur à un charactère
  // comme on le ferait pour un int sauf si on utilise un tableau de charactères
  char *a = (char *)malloc(26 * sizeof(char));
  char *C = (char *)malloc(26 * sizeof(char));
  strcpy(a, "abcdefghijklmnopqrstuvwxyz");
  strcpy(C, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
  printf("Test de la fonction to_lower\n");
  printf("to_lower(abcdefghijklmnopqrstuvwxyz): %s\n", to_lower(a));
  printf("to_lower(ABCDEFGHIJKLMNOPQRSTUVWXYZ): %s\n", to_lower(C));

  return EXIT_SUCCESS;
}
