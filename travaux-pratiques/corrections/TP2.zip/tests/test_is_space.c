
// Fichier de test de fonctions sur les chaines de caractères
#include <stdio.h>
#include <stdlib.h>
#include "../src/traitement_chaines.h"


int main(int argc, char *argv[])
{
  char a = ' ';
  char C = 'C';
  printf("Test de la fonction is_space\n");
  printf("is_space(%c): %d\n", a, is_space(a));
  printf("is_space(%c): %d\n", C, is_space(C));
  
  return EXIT_SUCCESS;
}
