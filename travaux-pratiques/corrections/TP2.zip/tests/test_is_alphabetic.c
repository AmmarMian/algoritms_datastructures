// Fichier de test de fonctions sur les chaines de caractères
#include <stdio.h>
#include <stdlib.h>
#include "../src/traitement_chaines.h"


int main(int argc, char *argv[])
{
  char a = 'a';
  char C = 'C';
  char d = '1';
  char espace = ' ';
  printf("Test de la fonction is_alphetic\n");
  printf("is_alphetic(%c): %d\n", a, is_alphetic(a));
  printf("is_alphetic(%c): %d\n", C, is_alphetic(C));
  printf("is_alphetic(%c): %d\n", d, is_alphetic(d));
  printf("is_alphetic(%c): %d\n", espace, is_alphetic(espace));
  
  return EXIT_SUCCESS;
}
