// Fichier de test de fonction encrypt_cesar
#include <stdio.h>
#include <stdlib.h>
#include "../src/caesar.h"


int main(int argc, char *argv[])
{
  char chaine[] = "Bonjour comment ca va";
  int decalage = 3;
  printf("Test de la fonction encrypt_cesar décalage de %d\n", decalage);
  printf("Chaine avant chiffrement: %s\n", chaine);
  encrypt_cesar(chaine, decalage);
  printf("Chaine après chiffrement: %s\n", chaine);

  char chaine2[] = "Hello WORLD";
  int decalage2 = 23;
  printf("Test de la fonction encrypt_cesar décalage de %d\n", decalage2);
  printf("Chaine avant chiffrement: %s\n", chaine2);
  encrypt_cesar(chaine2, decalage2);

  char chaine3[] = "Hello, WORLD!!!";
  int decalage3 = 23;
  printf("Test de la fonction encrypt_cesar décalage de %d et des caractères spéciaux\n", decalage3);
  printf("Chaine avant chiffrement: %s\n", chaine3);
  encrypt_cesar(chaine3, decalage3);
  printf("Chaine après chiffrement: %s\n", chaine3);

  return EXIT_SUCCESS;
}

