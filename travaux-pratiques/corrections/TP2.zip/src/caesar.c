#include "traitement_chaines.h"

void encrypt_cesar(char *chaine, int decalage) {
    to_lower(chaine);
    for (int i = 0; chaine[i] != '\0'; i++) {
       if (is_alphetic(chaine[i])){
          chaine[i] = (chaine[i] - 'a' + decalage) % 26 + 'a';
        } else if (!is_space(chaine[i])){
          printf("Erreur: la chaine contient des caractères non alphabétiques\n");
          // return;
        }
    }
}


void decrypt_cesar(char *chaine, int decalage) {
    to_lower(chaine);
    for (int i = 0; chaine[i] != '\0'; i++) {
       if (is_alphetic(chaine[i])){
          chaine[i] = (chaine[i] - 'a' - decalage + 26) % 26 + 'a';
        } else if (!is_space(chaine[i])){
          printf("Erreur: la chaine contient des caractères non alphabétiques\n");
          return;
        }
    }
}
