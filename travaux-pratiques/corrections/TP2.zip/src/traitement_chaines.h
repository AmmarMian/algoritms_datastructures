#include <stdio.h>

char * get_line(FILE * f);
char *read_text(int size_max, char* prompt);
int is_alphetic(char c);
int is_space(char c);
char* to_lower(char* text);

