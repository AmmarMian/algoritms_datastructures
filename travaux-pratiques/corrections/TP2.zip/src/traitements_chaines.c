#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>



char * get_line(FILE * f)
{
    size_t size = 0;
    size_t len  = 0;
    size_t last = 0;
    char * buf  = NULL;

    do {
        size += BUFSIZ; /* BUFSIZ is defined as "the optimal read size for this platform" */
        buf = realloc(buf,size); /* realloc(NULL,n) is the same as malloc(n) */            
        /* Actually do the read. Note that fgets puts a terminal '\0' on the
           end of the string, so we make sure we overwrite this */
        fgets(buf+last,size,f);
        len = strlen(buf);
        last = len - 1;
    } while (!feof(f) && buf[last]!='\n');
    return buf;
}


char *read_text(int size_max, char* prompt){
    char *text = (char *)malloc(size_max * sizeof(char));
    if (text == NULL){
        printf("Erreur d'allocation de mémoire\n");
        return NULL;
    }
    printf("%s", prompt);
    scanf("%s", text);
    return text;
}

int is_alphetic(char c){
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

int is_space(char c){
    return c == ' ';
}

char* to_lower(char* text){
    int i = 0;
    while (text[i] != '\0'){
        if (text[i] >= 'A' && text[i] <= 'Z'){
            text[i] = text[i] + 32;
        }
        i++;
    }
    return text;
}


