int is_word(char* word, char* dictionary_path);
int count_valid_words(char* text, char* dictionary_path);
void decrypt_cesar_bruteforce(char* text, char* dictionary_path);
void print_decryption_bruteforce_file(char* filename, char* dictionary_path);
