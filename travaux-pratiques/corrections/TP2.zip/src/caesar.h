void encrypt_cesar(char *chaine, int decalage);
void decrypt_cesar(char *chaine, int decalage);

