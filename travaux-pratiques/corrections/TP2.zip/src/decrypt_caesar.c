#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "caesar.h"
#include "traitement_chaines.h"


int is_word(char* word, char* dictionary_path) {
    FILE *file = fopen(dictionary_path, "r");
    if (file == NULL) {
        printf("Error: File not found\n");
        exit(1);
    }
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        //Remove newline character
        line[strcspn(line, "\n")] = 0;
        // Remove space at end ofnline somehow@
        line[strlen(line)-1] = 0;
        to_lower(line);
        to_lower(word);
        if (strcmp(word, line) == 0) {
            fclose(file);
            return 1;
        }
    }
    fclose(file);
    return 0;
}


int count_valid_words(char* text, char* dictionary_path) {
    int count = 0;
    char* word = strtok(text, " ");
    while (word != NULL) {
        if (is_word(word, dictionary_path)) {
            count++;
        }
        word = strtok(NULL, " ");
    }
    return count;
}


void decrypt_cesar_bruteforce(char* text, char* dictionary_path) {
    int best_key;
    int best_count = 0;
    for (int i = 0; i < 26; i++) {
        char* decrypted_text = malloc(strlen(text) + 1);
        strcpy(decrypted_text, text);
        decrypt_cesar(decrypted_text, i);
        int count = count_valid_words(decrypted_text, dictionary_path);
        if (count > best_count) {
          best_count = count;
          best_key = i;
        }
        free(decrypted_text);
    }
    decrypt_cesar(text, best_key);
}


void print_decryption_bruteforce_file(char* filename, char* dictionary_path) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: File not found\n");
        exit(1);
    }
    char line[256];
    char decrypted_line[256];

    // int best_key = 0;
    // int best_count = 0;
    // for (int i = 0; i < 26; i++) {
    //   printf("Testing key %d\n", i);
    //   printf("----------------\n");
    //   int count = 0;
    //   while (fgets(line, sizeof(line), file)) {
    //       strcpy(decrypted_line, line);
    //       decrypt_cesar(decrypted_line, i);
    //       count += count_valid_words(decrypted_line, dictionary_path);
    //       // printf("count = %d for : %s\n", count, line);
    //   }
    //   if (count > best_count) {
    //       best_count = count;
    //       best_key = i;
    //   }
    //   printf("Valid words: %d\n", count);
    //   printf("Best key: %d\n\n", best_key);
    //   rewind(file);
    // }
    while (fgets(line, sizeof(line), file)) {
      printf("before %s", line); 
      decrypt_cesar_bruteforce(line, dictionary_path);
      printf("after %s", line);
    }
    fclose(file);
}
