
#define MAX_LENGTH 256

typedef struct {
    char name[MAX_LENGTH];
    float latitude;
    float longitude;

} City;


struct Node_city_st {
    struct Node_city_st *previous;
    City * city;
    struct Node_city_st *next;
};
typedef struct Node_city_st Node_city;

typedef struct {
    Node_city * head;
    Node_city * tail;
    int size;
} List_cities ;

typedef List_cities* Path ;


// Functions

/**
 * @brief Creates a new City object.
 * 
 * @param name The name of the city (string).
 * @param longitude The longitude of the city (float).
 * @param latitude The latitude of the city (float).
 * @return Pointer to the newly created City object.
 */
City* create_city(char name[MAX_LENGTH], float longitude, float latitude);

/**
 * @brief Frees the memory allocated for a City object.
 * 
 * @param city_p Pointer to the City object to be freed.
 */
void free_city(City* city_p);

/**
 * @brief Prints the details of a City object.
 * 
 * @param city Pointer to the City object to print.
 */
void print_city(City* city);

/**
 * @brief Creates a new node containing a City object for use in a doubly linked list.
 * 
 * @param city Pointer to the City object to be stored in the node.
 * @return Pointer to the newly created Node_city object.
 */
Node_city* create_node(City* city);

/**
 * @brief Frees the memory allocated for a Node_city object and the City it contains.
 * 
 * @param node Pointer to the Node_city object to be freed.
 */
void free_node(Node_city* node);

/**
 * @brief Creates a new, empty doubly linked list of cities.
 * 
 * @return Pointer to the newly created List_cities object.
 */
List_cities* create_list();

/**
 * @brief Adds a City to the end of the doubly linked list.
 * 
 * @param list Pointer to the List_cities object where the City will be added.
 * @param city Pointer to the City object to add to the list.
 */
void push(List_cities* list, City * city);

/**
 * @brief Frees the memory allocated for a doubly linked list of cities, including all nodes and cities within the list.
 * 
 * @param list Pointer to the List_cities object to be freed.
 */
void free_list_cities(List_cities* list);

/**
 * @brief Prints all cities in a doubly linked list.
 * 
 * @param list Pointer to the List_cities object to print.
 */
void print_list_cities(List_cities* list);

/**
 * @brief Reads city data from a file and creates a doubly linked list of City objects.
 * 
 * @param filename The name of the file containing city data in "name latitude longitude" format.
 * @return Pointer to the newly created List_cities object containing the city data.
 *         Returns NULL if the file could not be opened.
 */
List_cities* read_cities(char *filename);

