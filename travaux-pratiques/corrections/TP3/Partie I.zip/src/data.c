#include "data.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

City* create_city(char name[MAX_LENGTH], float longitude, float latitude){
    City* city_p = (City *) malloc(sizeof(City));
    strcpy(city_p->name, name);
    city_p->latitude = latitude;
    city_p->longitude = longitude;
    return city_p;

}

void free_city(City* city_p){
    free(city_p);
}

void print_city(City* city){
    printf("Ville : %s, Longitude : %f, Latitude : %f\n",
           city->name, city->longitude, city->latitude);
}


Node_city* create_node(City* city){
    Node_city* node = (Node_city *) malloc(sizeof(Node_city));
    node->city = city;
    node->next = NULL;
    node->previous = NULL;
    return node;
}

void free_node(Node_city* node){
    free_city(node->city);
    free(node);
}

List_cities* create_list(){
    List_cities* list = (List_cities *) malloc(sizeof(List_cities));
    list->size = 0;
    list->head = NULL;
    list->tail = NULL;
    return list;
}

void push(List_cities* list, City * city){
    Node_city* node = create_node(city);
    // Case list empty
    if (list->size == 0) {
        list->head = node;
        list->tail = node;
    } else {
        node->previous = list->tail;
        list->tail->next = node;
        list->tail = node;
    }
    list->size++;
}

void free_list_cities(List_cities* list){
    if (list->size != 0) {
        Node_city* current_node = list->head;
        Node_city* next_node = list->head->next;
        for (int i=0; i<list->size; i++) {
            if (current_node != NULL){
                free_node(current_node);
                current_node = next_node;
                if (next_node != NULL){
                    next_node = next_node->next;
                }
            }
        }
    }
}


void print_list_cities(List_cities* list){
    if (list->size != 0) {
        Node_city* current_node = list->head;
        for (int i=0; i<list->size-1; i++) {
            print_city(current_node->city);
            current_node = current_node->next;
        }
        print_city(current_node->city);
    }
}


List_cities * read_cities(char *filename){
  FILE *file = fopen(filename, "r");
  if (file == NULL){
    printf("Error: could not open file %s\n", filename);
    return NULL;
  }
  List_cities* list = create_list();
  char name[MAX_LENGTH];
  float latitude, longitude;
  while(fscanf(file, "%s %f %f", name, &latitude, &longitude) != EOF){
    City *city = create_city(name, latitude, longitude);
    push(list, city);
  }
  fclose(file);
  return list;
}
