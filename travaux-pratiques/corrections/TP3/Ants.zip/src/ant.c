#include "ant.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void initialize_random_seed() {
    srand(time(0)); // Seed the random number generator once
}


// Managing ants in memory
Ant* create_ant(List_cities* list_cities){

    // Sample random number
    int i = rand() % (list_cities->size);

    // Create ant
    Ant *ant = (Ant *) malloc(sizeof(Ant));
    ant->start_city = get_index(list_cities, i);
    ant->travelled_distance = 0;

    // Create list of travelled cities
    List_cities *list_travelled = create_list();
    push(list_travelled, ant->start_city);
    ant->travelled_cities = list_travelled;

    // Create list of remaining cities
    List_cities *list_remaining = create_list();
    Node_city *curr_node = list_cities->head;
    for (int j=0; j<list_cities->size; j++) {
        if (curr_node->city != ant->start_city) {
            push(list_remaining, curr_node->city);
        }
        if (j<list_cities->size-1){
            curr_node = curr_node->next;
        }
    }
    ant->remaining_cities = list_remaining;
    return ant;
}


void print_ant(Ant* ant){
    printf("Ant(start=%s, distance=%f)\n",
           ant->start_city->name, ant->travelled_distance);
}

void free_ant(Ant *ant){
    free(ant->remaining_cities);
    free(ant->travelled_cities);
    free(ant);
}


Ant** create_tab_ants(List_cities *list_cities, int n){
    Ant **tab_ants = (Ant **) malloc(n*sizeof(Ant *));
    for (int i=0; i<n; i++){
        Ant *ant = create_ant(list_cities);
        tab_ants[i] = ant;
    }
    return tab_ants;
}

void free_tab_ants(Ant** tab_ants, int n){
    for (int i=0; i<n; i++) {
        free_ant(tab_ants[i]);
    }
    free(tab_ants);
}
