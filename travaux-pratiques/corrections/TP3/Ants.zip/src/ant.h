#include "data.h"

typedef struct {
    City *start_city;
    List_cities *travelled_cities;
    float travelled_distance;
    List_cities *remaining_cities;
} Ant;


// Managing ants in memory
Ant* create_ant(List_cities* list_cities);
void free_ant(Ant *ant);
void print_ant(Ant* ant);
Ant** create_tab_ants(List_cities *list_cities, int n);
void free_tab_ants(Ant** tab_ants, int n);

// Random
void initialize_random_seed();
