#include "../src/data.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{

    City * paris = create_city("Paris", 30, -50);
    City * tokyo = create_city("Tokyo", 70, 50);
    City * new_york = create_city("New-York", 30, -90);
    City * sydney = create_city("Sydney", -40, 90);


    List_cities* list = create_list();
    push(list, paris);
    push(list, tokyo);
    push(list, new_york);
    push(list, sydney);
    print_list_cities(list);

    free_list_cities(list);
    return EXIT_SUCCESS;
}
