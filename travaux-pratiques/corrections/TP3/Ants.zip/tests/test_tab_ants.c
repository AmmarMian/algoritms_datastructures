#include <stdio.h>
#include <stdlib.h>
#include "../src/ant.h"


int main(int argc, char *argv[])
{
    
    // Initialise random seed
    initialize_random_seed();
    
    // Some cities
    char* filename = "data/all_cities.txt";
    List_cities* list = read_cities(filename);
    printf("List of cities :\n");
    print_list_cities(list);


    // Create tab of ants
    Ant **tab_ants = create_tab_ants(list, 100);
    
    // Print the tab
    printf("Tab of ants :\n");
    for (int i=0; i<100; i++) {
        print_ant(tab_ants[i]);
    }

    // Freeing memory
    free_tab_ants(tab_ants, 100);
    free_list_cities(list);


    return EXIT_SUCCESS;
}

