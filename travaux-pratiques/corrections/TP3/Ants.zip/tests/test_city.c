#include "../src/data.h"
#include <stdlib.h>


int main(int argc, char *argv[])
{
    char name[] = "Annecy";
    City* ville1 = create_city(name, 45.916, 6.133);
    City* ville2 = create_city("Orleans", 45.916, -6.133);
    City* ville3 = create_city("Tokyo", -45.916, 6.133);

    print_city(ville1);
    print_city(ville2);
    print_city(ville3);


    free_city(ville1);
    free_city(ville2);
    free_city(ville2);
    return EXIT_SUCCESS;
}
