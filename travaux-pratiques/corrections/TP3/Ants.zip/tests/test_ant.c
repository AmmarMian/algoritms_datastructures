#include <stdio.h>
#include <stdlib.h>
#include "../src/ant.h"


int main(int argc, char *argv[])
{
    
    // Initialise random seed
    initialize_random_seed();
    
    // Some cities
    char* filename = "data/example_small.txt";
    List_cities* list = read_cities(filename);
    printf("List of cities :\n");
    print_list_cities(list);


    // Create an ant
    Ant *ant = create_ant(list);
    printf("\nAnt created: ");
    print_ant(ant);

    // Create a second ant
    Ant *ant2 = create_ant(list);
    printf("Ant created: ");
    print_ant(ant2);



    // Freeing memory
    free_ant(ant);
    free_ant(ant2);
    free_list_cities(list);


    return EXIT_SUCCESS;
}
