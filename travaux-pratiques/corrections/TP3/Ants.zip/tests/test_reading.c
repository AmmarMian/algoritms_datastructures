#include <stdio.h>
#include <stdlib.h>
#include "../src/data.h"

int main(int argc, char *argv[])
{
    // Check for command-line arguments for data
    if (argc < 2){
        printf("Usage : %s filename\n", argv[0]);
        return EXIT_FAILURE;
    }
    char *filename = argv[1];
    
    // Read list from file
    printf("Reading from file: %s\n", filename);
    List_cities* list = read_cities(filename);

    // Print list
    print_list_cities(list);

    // Free list
    free_list_cities(list);
    return EXIT_SUCCESS;
}
